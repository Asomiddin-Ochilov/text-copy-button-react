import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'animate.css';
import "react-responsive-carousel/lib/styles/carousel.min.css"; 
import {BrowserRouter,Routes,Route} from 'react-router-dom'
import Main from './Components/Main';
import Popular from './Components/Popular';
import Info from './Components/Info';
import Info2 from './Components/Info2';
import Upcoming from './Components/Upcoming';
import NowPlaying from './Components/NowPlaying';
import Toprated from './Components/Toprated'
import People from './Components/People'
import Popular2 from './Components/TV_Shows/Popular2'
import Airing from './Components/TV_Shows/Airing'
import OnTv from './Components/TV_Shows/OnTv'
import Toprated2 from './Components/TV_Shows/TopRated2'
import Watchlist from './Components/Watchlist'
import { Provider } from "react-redux";
import store from './Components/store'
import Search from './Components/Search';
import AOS from 'aos';
import 'aos/dist/aos.css'; 


const root = ReactDOM.createRoot(document.getElementById('root'));

root.render(
  <React.StrictMode>
  <BrowserRouter>
  <Provider store={store}>
 <Routes>
      <Route path='/' element={<App />} />
      <Route path='/' element={<Main />} />
      <Route path='/movies/popular' element={<Popular />} />
      <Route path='/movies/playing' element={<NowPlaying />} />
      <Route path='/movies/toprated' element={<Toprated />} />
      <Route path='/movies/search/:name' element={<Search />} />
      <Route path='/people/popularpeople' element={<People />} />
      <Route path='/movies/upcoming' element={<Upcoming />} />
      <Route path='/movies/popular/:id' element={<Info />} />
      <Route path='/movies/people/:id' element={<Info2 />} />
      <Route path='/tvshows/popular/' element={<Popular2 />} />
      <Route path='/tvshows/airing/' element={<Airing />} />
      <Route path='/tvshows/ontv/' element={<OnTv />} />
      <Route path='/tvshows/toprated/' element={<Toprated2 />} />
      <Route path='/watchlist/' element={<Watchlist />} />
    </Routes>
  </Provider>
   
  </BrowserRouter>
 
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
AOS.init();
