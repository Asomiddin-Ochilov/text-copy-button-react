import React, {useState,useEffect} from 'react'
import axios from 'axios'
import { Link, useNavigate } from 'react-router-dom';
import BookmarkIcon from '@mui/icons-material/Bookmark';
import { useDispatch } from 'react-redux';
import { addCardItem } from "./state";
import { PageHeader, Button, Radio, Descriptions } from 'antd';
import Checkbox from '@mui/material/Checkbox';
import FavoriteBorder from '@mui/icons-material/FavoriteBorder';
import Favorite from '@mui/icons-material/Favorite';
import BookmarkBorderIcon from '@mui/icons-material/BookmarkBorder';



export default function Main() {
  let navigate = useNavigate()
  let dispatch = useDispatch()
 const [massiv, setMassiv] = useState([]);
 const [two, setTwo] = useState([]);
 const [three, setThree] = useState([]);
 const [size, setSize] = useState('large');
 const [four, setFour] = useState([]);
 const [status, setStatus] = useState(true);
 const [input, setInput] = useState("");
 const [change, setChange] = useState(true);
 


     const api_key = "a65b5937cb45a85fc91cb5e8065787f1"
     const images = "https://image.tmdb.org/t/p/w500"

     const label = { inputProps: { 'aria-label': 'Checkbox demo' } };

     useEffect(() => {

       axios.get(`https://api.themoviedb.org/3/movie/popular?api_key=${api_key}&language=en-US&page=1`)
    .then((response) => {
        setMassiv(response.data.results)

    })
    axios.get(`https://api.themoviedb.org/3/tv/top_rated?api_key=${api_key}&language=en-US&page=1`)
    .then((response) => {
      setTwo(response.data.results)
    
    })
    axios.get(`https://api.themoviedb.org/3/trending/all/day?api_key=${api_key}`)
    .then((response) => {
      setThree(response.data.results)
    })
    axios.get(`https://api.themoviedb.org/3/trending/all/week?api_key=${api_key}`)
     .then((response) => {
       setFour(response.data.results)
     })
    
   

     }, []);

     const my_filter =  two.filter((item) => {
       if (item.backdrop_path != null) {
         return item
       }
     })
     console.log(my_filter);
     console.log(two);

     function GetValue(val) {
       setInput(val.target.value)
       
     }



   
    if (massiv.length == 0) {
      <h1>Loading!!!</h1>
    }
    if (two.length == 0) {
      <h1>Loading!!!</h1>
    }
    if (three.length == 0) {
      <h1>Loading!!!</h1>
    }
    if (four.length == 0) {
      <h1>Loading!!!</h1>
    }
    const getTv = () => {
      setStatus(false)
    }
    const getPopular = () => {
      setStatus(true)
    }
    const getToday = () => {
      setChange(true)
    }
    const getWeek = () => {
      setChange(false)
    }
    function PostItem(item) {
      
    
      dispatch(addCardItem(item));
     
    }

  
  return (
    <div className='main'>
    <div className='container'>
     <div className='main_img' 
     data-aos="fade-right"
     data-aos-duration="1000"
     data-aos-easing="ease-in-sine">
     <div className='color '>
            <h1 className=''
            data-aos="fade-right"
            data-aos-duration="1500"
     data-aos-easing="ease-in-sine">Welcome.</h1>
        <h1 className='fs-2 ' 
        data-aos="fade-right"
        data-aos-duration="1500"
     data-aos-easing="ease-in-sine">Millions of movies, TV shows and people to discover. Explore now.</h1>
        <div className='form'>
        <input type='text' onInput={(item) => GetValue(item)} placeholder="Search for a movie , tv show, person....." />
      <Link to={`movies/search/${input}`}>
         <button>Search</button>
      </Link>
       
     </div>
      
        </div>
     </div>
     <div className='d-flex my-3'
      data-aos="fade-right"
        data-aos-duration="1500"
     data-aos-easing="ease-in-sine">
         <h1 className='fs-3 mx-2'>What's Popular</h1>
         <Button size={size} key="2" onClick={getPopular} className='btn rounded-0  border border-dark'>On TV</Button>
         <Button key="3" onClick={getTv} className='btn border rounded-0 border-dark' >In Theaters</Button>
     </div>
    <div className='scroll_carousel'
     data-aos="fade-up"
     data-aos-duration="3000"> 
     {
       (status)?
       massiv.map((item , index) => {
         return(
           <div key={index}  className='my_cards'>
           <Link to={`/movies/popular/${item.id}`}>
           <img style={{borderRadius:"20px"}} height="300px" width="80%" src={images + item.backdrop_path }/>
           </Link>
           <h5 style={{marginTop:'30px'}}>{item.title}</h5>
           <p>{item.release_date}</p>
           <div className='absolute'>{item.vote_average}</div>
           <Checkbox

            {...label}
           icon={<BookmarkBorderIcon className='fs-2' />}
           checkedIcon={<BookmarkIcon className='text-dark fs-2' />}
           onClick={ () => PostItem(item)}
           
           className='my_icon' 
             />
           {/* <BookmarkIcon onClick={ () => PostItem(item)} className='my_icon'  /> */}
           </div>
         )
       })
       :
       my_filter.map((item , index) => {
         return(
           <div key={index}  className='my_cards'>
           <Link to={`/movies/popular/${item.id}`}>
           <img style={{borderRadius:"20px"}} height="300px" width="80%" src={images + item.backdrop_path } alt="Not Img"/>
           </Link>
           <h5 style={{marginTop:'30px'}}>{item.name}</h5>
           <p>{item.first_air_date}</p>
           <div className='absolute'>{item.vote_average}</div>
           <Checkbox

          {...label}
          icon={<BookmarkBorderIcon className='fs-2' />}
          checkedIcon={<BookmarkIcon className='text-dark fs-2' />}
          onClick={ () => PostItem(item)}

          className='my_icon' 
 />
     
           </div>
         )
       })

     }

    </div>
    <div className='d-flex my-3'
      data-aos="fade-right"
        data-aos-duration="1500"
     data-aos-easing="ease-in-sine">
         <h1 className='fs-3 mx-2'>Trending</h1>
         <button onClick={getToday} className='btn_1 rounded-0 border btn border-dark'>Today</button>
         <button onClick={getWeek} className='btn_2 rounded-0 border btn border-dark'>This week</button>
     </div>

     <div className='scroll_carousel'
       data-aos="fade-up"
     data-aos-duration="3000">
     {
       (change) ?
       three.map((item , index) => {
         return(
           <div key={index}  className='my_cards'>
           <Link to={`/movies/popular/${item.id}`}>
           <img style={{borderRadius:"20px"}} height="300px" width="80%" src={images + item.backdrop_path } alt="Not Img"/>
           </Link>
           <h5 style={{marginTop:'30px'}}>{item.title || item.name}</h5>
           <p>{item.release_date || item.first_air_date}</p>
           <div className='absolute'>{item.vote_average}</div>
           <Checkbox

            {...label}
           icon={<BookmarkBorderIcon className='fs-2' />}
           checkedIcon={<BookmarkIcon className='text-dark fs-2' />}
           onClick={ () => PostItem(item)}
           
           className='my_icon' 
             />

           </div>
         )
       })
       : 
       four.map((item , index) => {
         return(
           <div key={index}  className='my_cards'>
           <Link to={`/movies/popular/${item.id}`}>
              <img style={{borderRadius:"20px"}} height="300px" width="80%" src={images + item.backdrop_path } alt="Not Img"/>
           </Link>
           <h5 style={{marginTop:'30px'}}>{item.name || item.title}</h5>
           <p>{item.first_air_date || item.release_date}</p>
           <div className='absolute'>{item.vote_average}</div>
           <Checkbox

            {...label}
           icon={<BookmarkBorderIcon className='fs-2' />}
           checkedIcon={<BookmarkIcon className='text-dark fs-2' />}
           onClick={ () => PostItem(item)}
           
           className='my_icon' 
             />

           </div>
         )
       })
     }
     </div>

     <section className='bg_2'
       data-aos="fade-up"
     data-aos-duration="3000">
     <div  className='d-flex bg_3 '>
        <div  style={{width: '60%',padding:'25px'}}>
        <h2 style={{padding:'10px', }} className='text-start'
          data-aos="fade-up"
     data-aos-duration="3000">Join Today</h2>
        <p style={{width:'80%', }} className="text-start"
          data-aos="fade-up"
     data-aos-duration="3000">Get access to maintain your own custom personal lists, track what you've seen and search and filter for what to watch next—regardless if it's in theatres, on TV or available on popular streaming services like </p>
        <button  className='btn btn-danger d-flex '
          data-aos="fade-up"
     data-aos-duration="3000">Sign Up</button>
       </div>
       <div style={{width:"40%", padding:"30px"}}>
        <ul className='d-flex flex-column my_ul2'>
          <li   data-aos="fade-up"
     data-aos-duration="3000">Enjoy TMDB ad free</li>
          <li   data-aos="fade-up"
     data-aos-duration="3000">Maintain a personal watchlist</li>
          <li   data-aos="fade-up"
     data-aos-duration="3000">Filter by your subscribed streaming services and find something to watch</li>
          <li   data-aos="fade-up"
     data-aos-duration="3000">Log the movies and TV shows you've seen</li>
          <li   data-aos="fade-up"
     data-aos-duration="3000">Build custom lists</li>
          <li   data-aos="fade-up"
     data-aos-duration="3000">Contribute to and improve our database</li>
        </ul>
       </div>
     </div>
      
     </section>
    </div>
    </div>
  )
}
