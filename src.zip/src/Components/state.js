import { createSlice } from "@reduxjs/toolkit";

export const addCardItem = (item) => {
  return (dispatch) => {
    console.log(item);

    dispatch({
      type: addCard.type,
      payload: item,
    });
  };
};

const Card = createSlice({
  name: "card",

  initialState: {
    cards: [],
    filters: [],
    genres: [],
  },

  reducers: {
    addfilters: (state, action) => {
      console.log(action);
      // state.cards.push(action.payload);
    },
    addCard: (state, action) => {
      console.log(action);
      state.cards.push(action.payload);
    //  cards setItem saqlaydi
      localStorage.setItem("cards", JSON.stringify(state.cards));

      // buni karzinka komponentga quyvorasiz state qilib ishlatib ketoverasiz
    // const[state,setState] = useState(JSON.parse(localStorage.getItem("cards")))
      
    },
    addgenres: (state, action) => {
      console.log(action);
      state.genres.push(action.payload);
    },
  },
});

export const { addCard } = Card.actions;
export const { addgenres } = Card.actions;
export const { addfilters } = Card.actions;
export default Card.reducer;
