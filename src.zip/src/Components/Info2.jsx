import axios from 'axios';
import React , {useEffect, useState} from 'react'
import { Row ,Col} from 'react-bootstrap';
import { Link, useParams } from 'react-router-dom'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faMagnifyingGlass , faEllipsis} from '@fortawesome/free-solid-svg-icons'
import { Spin } from 'antd';
import { LoadingOutlined } from '@ant-design/icons';
import BookmarkIcon from '@mui/icons-material/Bookmark';
import { useDispatch } from 'react-redux';
import { addCardItem } from "./state";
import Header from './Header';
import Checkbox from '@mui/material/Checkbox';
import BookmarkBorderIcon from '@mui/icons-material/BookmarkBorder';


export default function Info2() {
  let dispatch = useDispatch()
    const[loading,setLoading] = useState(false)
    const[first,setFirst] = useState([])
    const[two,setTwo] = useState([])
    let params = useParams()
    let id = params.id

    function PostItem(item) {
        dispatch(addCardItem(item))
        item.classlist.add('my_icon_2')
      }
    const my_item = two.filter(item => {
       if(item.backdrop_path != null) {
         return item
       }
       console.log(item);
      
    })


    const api_key = "a65b5937cb45a85fc91cb5e8065787f1"
     const images = "https://image.tmdb.org/t/p/w500"
  const label = { inputProps: { 'aria-label': 'Checkbox demo' } };


    useEffect(() => {
        axios.get(`https://api.themoviedb.org/3/person/${id}?api_key=${api_key}&language=en-US`)
        .then((response) => {
           setFirst(response.data)
           setLoading(true)
        })
        axios.get(`https://api.themoviedb.org/3/person/${id}/movie_credits?api_key=${api_key}&language=en-US`)
        .then((response) => {
            console.log(response.data.cast);
            setTwo(response.data.cast)

        })
      }, []);
  return (
    <div className='Info' >
    <Header />
     {
         (loading) ?
         <Row>
             <Col md={3}>
         <img  data-aos="fade-right"
        data-aos-duration="1500"
     data-aos-easing="ease-in-sine" className='border_3'  height="600px" style={{padding:"30px", borderRadius:"30px"}} src={images +  first.profile_path} />
         </Col>
         <Col  data-aos="fade-right"
        data-aos-duration="1500"
     data-aos-easing="ease-in-sine" style={{padding:"30px"}} md={9}>
          <h1>{first.name}</h1>
          <h3 className='text-success'>Birthday: {first.birthday}</h3>
          <h3 className='text-danger'>{first.place_of_birth}</h3>
          <h1>Biography:</h1>
          <h5>{first.biography}</h5>
 
         </Col> 
         <h3 style={{textAlign:'center'}}  data-aos="fade-right"
        data-aos-duration="1500"
     data-aos-easing="ease-in-sine">Known For</h3>
         <div className='my_carousel' data-aos="fade-up"
     data-aos-duration="3000">
          
           {
               (my_item.length > 0) && my_item.map((item,index) => {
                   return(
                    <div key={index}  className='my_cards info_card'>
                    <Link to={`/movies/popular/${item.id}`}>
                   <img style={{borderRadius:"20px"}} height="300px" width="80%" src={images + item.backdrop_path || images + item.poster_path } alt="Not Img"/>    
                    </Link>
           <h5 style={{marginTop:'30px'}}>{item.title}</h5>
           <p>{item.release_date}</p>
           <div className='absolute'>{item.vote_average}</div>
           <Checkbox

            {...label}
            icon={<BookmarkBorderIcon className='fs-2' />}
            checkedIcon={<BookmarkIcon className='text-dark fs-2' />}
            onClick={ () => PostItem(item)}

            className='my_icon' 
            />
           </div>
                   )
               })
           }
         </div>

         </Row>
        

         :

         <LoadingOutlined  style={{ fontSize: 84, marginLeft:'100px' }} spin />
        
     }
         
    </div>
  )
}
