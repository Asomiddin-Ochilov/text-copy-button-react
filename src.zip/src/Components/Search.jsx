import React, {useState,useEffect} from 'react'
import axios from 'axios'
import { Link, useNavigate , useParams} from 'react-router-dom';
import BookmarkIcon from '@mui/icons-material/Bookmark';
import { useDispatch } from 'react-redux';
import { addCardItem } from "./state";
import { PageHeader, Button, Descriptions, } from 'antd';
import { Row , Col } from 'react-bootstrap';
import Header from './Header'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faMagnifyingGlass , faPlus} from '@fortawesome/free-solid-svg-icons'
import { padding } from '@mui/system';

export default function Search() {
    let params = useParams()
    let search = params.name
    console.log(params);
    
 const [word, setWord] = useState();
 const [person, setPerson] = useState([]);

    const api_key = "a65b5937cb45a85fc91cb5e8065787f1"
    const images = "https://image.tmdb.org/t/p/w500"

   const my_filter = person.filter(item => {
       if (item.profile_path != null) {
           return item
       }
   })
   useEffect(() => {
       axios.get(`https://api.themoviedb.org/3/search/movie?api_key=${api_key}&language=en-US&query=${search}&page=1`)
       .then((response) => {
          setWord(response.data.results)
         
       })

       axios.get(`https://api.themoviedb.org/3/search/person?api_key=${api_key}&language=en-US&query=${search}&page=1`)
       .then((response) => {
          console.log('person' , response.data.results);
          setPerson(response.data.results)
         
       })
      
     }, []);

     
  return (
    <div className='backgrounds'>
    <Header />
    <div className='container'>
    <h1 style={{padding:'10px 0',  marginTop:'20px', display:'flex',justifyContent:'space-between' }}>Search <FontAwesomeIcon style={{color:'skyblue'}} icon={faMagnifyingGlass} /></h1>
    <hr></hr>

    <div className='my_carousel'>
         
         {
             (my_filter.length > 0) && my_filter.map((item,index) => {
                 return(
                  <div key={index}  className='my_cards info_card'>
                  <Link to={`/movies/people/${item.id}`}>
                            <img style={{borderRadius:"20px"}} height="300px" width="80%" src={images + item.profile_path } alt="Not Img"/>    
                  </Link>
         <h5 style={{marginTop:'30px'}}>{item.name}</h5>
         <p>{item.release_date}</p>
        
         </div>
                 )
             })
         }
       </div>
    <Row  data-aos="fade-up"
     data-aos-duration="3000">
        {
         word && word.map((item,index) => {
             return(
                 <Row className='search'>
                     <Col md={4}>
                     <Link  to={`/movies/popular/${item.id}`}>
                       <img width="100%" src={images + item.poster_path} />  
                     </Link>
                     </Col>
                     <Col md={8}>
                     <h1>{item.title || item.name}</h1>
                     <h2 className='text-success'>({item.release_date || item.first_air_date})</h2>
                     <h2>Popularity: {item.vote_average}</h2>
                     <h3 className='text-danger'>Overwiew:</h3>
                     <h5>{item.overview}</h5>

                     </Col>
                 </Row>
             )
         })
        }
    </Row>
     
   
    </div>
    </div>
  )
}
