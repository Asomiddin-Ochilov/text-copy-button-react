import axios from 'axios'
import React,{useEffect,useState} from 'react'
import { Col, Row } from 'react-bootstrap'
import { Link } from 'react-router-dom'
import Header from '../Header'
import BookmarkIcon from '@mui/icons-material/Bookmark';
import { useDispatch, useSelector } from 'react-redux'
import { addCardItem } from "../state";
import Checkbox from '@mui/material/Checkbox';
import BookmarkBorderIcon from '@mui/icons-material/BookmarkBorder';


export default function Popular() {
  let dispatch = useDispatch()
  let selector = useSelector(state => state.Card.genres)
const[ popular , setPopular] = useState([])
const[ loading , setLoading] = useState(false)



  const api_key = "a65b5937cb45a85fc91cb5e8065787f1"
  const images = "https://image.tmdb.org/t/p/w500"
  const label = { inputProps: { 'aria-label': 'Checkbox demo' } };


   useEffect(() => {

   axios.get(`https://api.themoviedb.org/3/tv/on_the_air?api_key=${api_key}&language=en-US&page=1`)
  .then((response) => {
    setLoading(true)
    setPopular(response.data.results)
    console.log(response.data.results);
    
    
  })
   }, []);
   const img_filter = popular.filter(item => {
    if (item.backdrop_path || item.poster_path == null) {
      return item 
    }
  })

  function PostItem(item) {
    dispatch(addCardItem(item))
  }


  return (
    <div className='backgrounds'>
    <Header />
    <div className='container'>
     
     <Row>
       <Col md={3}> 

       </Col>
       <Col md={9}>
       <h3 style={{marginTop: '30px'}}  data-aos="fade-right"
        data-aos-duration="1500"
     data-aos-easing="ease-in-sine">Tv Shows On TV</h3>
       <Row  data-aos="fade-up"
     data-aos-duration="3000">
        {
           (loading ) ?
           img_filter.map((item,index) => {
            return(
                <Col style={{borderRadius:"30px"}} className='my_card_popular ' md={3}>
                  <div  className='my-5 shadow my_card_2' key={index}>
                  <Link style={{textDecoration: 'none'}} to={`/movies/popular/${item.id}`}>
             <img style={{borderRadius:"20px"}} height="300px" width="100%" src={images + item.backdrop_path || images + item.poster_path } alt="Not Img"/>
             </Link>
              <h5 style={{marginTop:'40px'}}>{item.title || item.name}</h5>
               <p>{item.release_date || item.first_air_date}</p>
               <div className='absolute'>{item.vote_average}</div>
               <Checkbox

                {...label}
                icon={<BookmarkBorderIcon className='fs-2' />}
                checkedIcon={<BookmarkIcon className='text-dark fs-2' />}
                onClick={ () => PostItem(item)}

                className='my_icon_special' 
                />

                  </div>
                
                 
            
              </Col> 
             
            )
          })
          
          :
           <h1>Loading...</h1>
        }
        </Row>
       </Col>
     </Row>
    </div>
    
    
    </div>
  )
}