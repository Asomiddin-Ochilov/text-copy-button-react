import React from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faMagnifyingGlass , faPlus} from '@fortawesome/free-solid-svg-icons'
import {NavDropdown} from 'react-bootstrap'
import { Link, useNavigate } from 'react-router-dom'

export default function Header() {
  const navigate = useNavigate() 
   const GetPush = () => {
    navigate('/movies/popular')
   }
   const GetMain = () => {
     navigate('/')
   }
   const LogIn = () => {
     navigate('/movies/playing')
   }
   const GetPush3 = () => {
    navigate('/movies/upcoming')
  }
  const GetPush4 = () => {
    navigate('/movies/toprated')
  }
  const Getpeople = () => {
    navigate('/people/popularpeople')
  }
  const GetTvPopular = () => {
    navigate('/tvshows/popular')
  }
  const GetTvAiring = () => {
    navigate('/tvshows/airing')
  }
  const GetOnTv = () => {
    navigate('/tvshows/ontv')
  }
  const GetTopRated = () => {
    navigate('/tvshows/toprated')
  }
  const GetObject = () => {
    navigate('/watchlist/')
  }


  return (
    <div>
        <header>
        <div className='container'>
          <nav>
          <div className='flex_1'>
          <img  onClick={GetMain} style={{paddingBottom: "12px"}} width="150px" height="40px" src='https://www.themoviedb.org/assets/2/v4/logos/v2/blue_short-8e7b30f73a4020692ccca9c88bafe5dcb6f8a62a4c6bc55cd9ba82bb2cd95f6c.svg' alt='header_img' />
           <ul>
             <div>
                <li className='movies'>  
                  <NavDropdown
                  style={{color:"white"}}
            id="nav-dropdown-dark-example"
            title="Movies"
           menuVariant="light"
              >  
                    <NavDropdown.Item onClick={GetPush} style={{textAlign:"center"}} >Popular</NavDropdown.Item>
          <NavDropdown.Item onClick={LogIn} style={{textAlign:"center"}}>Now Playing</NavDropdown.Item>
          <NavDropdown.Item onClick={GetPush3} style={{textAlign:"center"}}>Upcoming</NavDropdown.Item>
          <NavDropdown.Item onClick={GetPush4} style={{textAlign:"center"}} >Top Rated</NavDropdown.Item>
              </NavDropdown>
        </li>
             </div>
             <div>
                <li>
                <NavDropdown
                  style={{color:"white"}}
            id="nav-dropdown-dark-example"
            title="TV Shows"
           menuVariant="light"
        >
          <NavDropdown.Item onClick={GetTvPopular} style={{textAlign:"center"}} >Popular</NavDropdown.Item>
          <NavDropdown.Item onClick={GetTvAiring}  style={{textAlign:"center"}}>Airing Today</NavDropdown.Item>
          <NavDropdown.Item onClick={GetOnTv} style={{textAlign:"center"}}>On TV</NavDropdown.Item>
          <NavDropdown.Item onClick={GetTopRated} style={{textAlign:"center"}} >Top Rated</NavDropdown.Item>
              </NavDropdown>
                </li>
             </div>
            <div>
            <li>
            <NavDropdown
            style={{color:"white"}}
            id="nav-dropdown-dark-example"
            title="People"
           menuVariant="light"
        >
          <NavDropdown.Item onClick={Getpeople} style={{textAlign:"center"}} >Popular People</NavDropdown.Item>
     
              </NavDropdown>
            </li>
            </div>
            <div>
              <li>
              <NavDropdown
                  style={{color:"white"}}
            id="nav-dropdown-dark-example"
            title="More"
           menuVariant="light"
        >
          <NavDropdown.Item style={{textAlign:"center"}} >Discussions</NavDropdown.Item>
          <NavDropdown.Item  style={{textAlign:"center"}}>Loaderboard</NavDropdown.Item>
          <NavDropdown.Item onClick={GetObject} style={{textAlign:"center"}}><b>Watchlist </b></NavDropdown.Item>
          <NavDropdown.Item style={{textAlign:"center"}} >API</NavDropdown.Item>
              </NavDropdown>
              </li>
            </div>
           </ul>
           </div>
           <div className='flex_2'>
            <ul>
            <li><FontAwesomeIcon icon={faPlus} style={{fontSize:"large"}} /></li>
            <li>Join TMDB</li>
            <li>UZ</li>
            <li>Login</li>
              <li><FontAwesomeIcon style={{color:"skyblue" , fontSize:'20px'}} icon={faMagnifyingGlass} /></li>
            </ul>
           </div>
          </nav> 
        </div>
        </header>
    </div>
  )
}
