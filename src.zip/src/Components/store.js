import {configureStore} from '@reduxjs/toolkit'
import Card from './state'

export default configureStore({
    reducer: {
        Card, 

    }
})
