import axios from 'axios'
import React,{useEffect,useState} from 'react'
import { Col, Row } from 'react-bootstrap'
import { Link } from 'react-router-dom'
import Header from './Header'
import BookmarkIcon from '@mui/icons-material/Bookmark';
import { useSelector } from 'react-redux'


export default function Popular() {
    let selector = useSelector(state => state.Card.cards)
    console.log(selector);
const[ popular , setPopular] = useState([])
const[ loading , setLoading] = useState(false)

  const api_key = "a65b5937cb45a85fc91cb5e8065787f1"
  const images = "https://image.tmdb.org/t/p/w500"

   useEffect(() => {

   axios.get(`https://api.themoviedb.org/3/movie/now_playing?api_key=${api_key}&language=en-US&page=1`)
  .then((response) => {
    setLoading(true)
    response.data.results.reverse()
    console.log(response.data.results);
    setPopular(response.data.results)
    
    
  })
   }, []);




  return (
    <div className='backgrounds'>
    <Header />
    <div className='container'>
    <h1 style={{padding:'10px 0'}}  data-aos="fade-right"
        data-aos-duration="1500"
     data-aos-easing="ease-in-sine">Watchlist</h1>
    <hr></hr>
    <Row  data-aos="fade-up"
     data-aos-duration="3000">
        {
         selector && selector.map((item,index) => {
             return(
                 <Row className='watchlist'>
                     <Col md={4}>
                    <img width="100%" src={images + item.poster_path} />
                     </Col>
                     <Col md={8}>
                     <h1>{item.title || item.name}</h1>
                     <h2 className='text-success'>({item.release_date || item.first_air_date})</h2>
                     <h2>Popularity: {item.vote_average}</h2>
                     <h3 className='text-danger'>Overwiew:</h3>
                     <h5>{item.overview}</h5>

                     </Col>
                 </Row>
             )
         })
        }
    </Row>
     
   
    </div>
    </div>
  )
}
