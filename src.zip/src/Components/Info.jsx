import axios from 'axios';
import React , {useEffect, useState} from 'react'
import { Row ,Col} from 'react-bootstrap';
import { Link, useParams } from 'react-router-dom'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faMagnifyingGlass , faEllipsis} from '@fortawesome/free-solid-svg-icons'
import { Spin } from 'antd';
import { LoadingOutlined } from '@ant-design/icons';
import Header from './Header';


export default function Info() {
    const [first, setFirst] = useState();
    const [two, setTwo] = useState();
    const[loading,setLoading] = useState(false)
    const[change,setChange] = useState(false)
    const[genres,setGenres] = useState(null)
    const[company,setCompany] = useState(null)
    let params = useParams()
    let id = params.id

    const api_key = "a65b5937cb45a85fc91cb5e8065787f1"
    const images = "https://image.tmdb.org/t/p/w500"



    useEffect(() => {
      axios.get(`https://api.themoviedb.org/3/movie/${id}?api_key=${api_key}&language=en-US`)
      .then((response) => {
          setTimeout(() => {
            setFirst(response.data)
          setLoading(true)
          setGenres(response.data.genres);
          setCompany(response.data.production_companies)
          setChange(true)    
          }, 500);
      })
       axios.get(`https://api.themoviedb.org/3/movie/${id}/credits?api_key=${api_key}&language=en-US`)
       .then((response) => {
         console.log(response.data.cast);
         const my_filter = response.data.cast.filter(item => {
          if(item.profile_path != null) {
            return item
          }
    
        })
         setTwo(my_filter)
   

       })



    }, []);
    console.log(first);
   
  return (
    <div className='Info' >
    <div className='background_2'>
       <Header />
     {
         (loading) ?
         <Row>
             <Col md={3}>
         <img  data-aos="fade-right"
        data-aos-duration="1500"
     data-aos-easing="ease-in-sine" height="600px" style={{padding:"30px", borderRadius:"20px"}} src={images +  first.poster_path} />
         <h3  data-aos="fade-right"
        data-aos-duration="1500"
     data-aos-easing="ease-in-sine" className='mx-4 text-danger'>Popularity:</h3>
         <h5  data-aos="fade-right"
        data-aos-duration="1500"
     data-aos-easing="ease-in-sine" className='mx-4'>{first.popularity}</h5>
         <h3  data-aos="fade-right"
        data-aos-duration="1500"
     data-aos-easing="ease-in-sine" className='mx-4 text-danger'>Revenue:</h3>
         <h5  data-aos="fade-right"
        data-aos-duration="1500"
     data-aos-easing="ease-in-sine" className='mx-4'>{first.revenue}</h5>
         <h3  data-aos="fade-right"
        data-aos-duration="1500"
     data-aos-easing="ease-in-sine" className='mx-4 text-danger'>Runtime:</h3>
         <h5  data-aos="fade-right"
        data-aos-duration="1500"
     data-aos-easing="ease-in-sine" className='mx-4'>{first.runtime}</h5>



         
         
         </Col>
         <Col  data-aos="fade-right"
        data-aos-duration="1500"
     data-aos-easing="ease-in-sine" style={{padding:"30px"}} md={9}>
          <h1>{first.title}</h1>
          <h4 className='text-success'>{first.release_date}</h4>
          <h3>{first.tagline}</h3>
          <h1>Overwiew</h1>
          <h5>{first.overview}</h5>
          <Row  data-aos="fade-right"
        data-aos-duration="1500"
     data-aos-easing="ease-in-sine">
          {    
             genres && genres.map((item,index) => {
                  return(
                      <Col md={3}>
                        <h3 className='text-danger'>{item.name}</h3>
                      </Col>
                  )
              })
          }
          </Row>
          <Row  data-aos="fade-right"
        data-aos-duration="1500"
     data-aos-easing="ease-in-sine">
              {    
                 company && company.map((item,index) => {
                      return(
                       <Col style={{marginTop:"40px"}} md={3}>
                       <img width="200px" src={images + item.logo_path} />
                       <h6 style={{marginTop:"20px"}}>{item.name}</h6>
                       </Col>   
                      )
                  })
                  
              }
          </Row>
          <h3 style={{marginTop:'40px'}}  data-aos="fade-right"
        data-aos-duration="1500"
     data-aos-easing="ease-in-sine">Top Billed Cast</h3>
          <div className='my_carousel'  data-aos="fade-up"
     data-aos-duration="3000">
            {
              (two.length > 0) && two.map((item,index) => {
                return(
                  <div key={index}  className='my_cards info_card'>
                  <Link to={`/movies/people/${item.id}`} >
                 <img style={{borderRadius:"20px"}} height="300px" width="80%" src={images + item.profile_path || images + item.poster_path } alt="Not Img"/>    
                  </Link>
            
            <h3 style={{marginTop:'30px'}}>{item.character}</h3>
            <h6>{item.name}</h6>
           </div>
                )
              })
            }
          </div>
         </Col> 
         </Row>

         :

         <LoadingOutlined  style={{ fontSize: 84, marginLeft:'100px' }} spin />
        
     }
         
    </div>
   
    </div>
  )
}
