import axios from 'axios'
import React,{useEffect,useState} from 'react'
import { Col, Row } from 'react-bootstrap'
import { Link } from 'react-router-dom'
import Header from './Header'

export default function Popular() {
const[ popular , setPopular] = useState([])
const[ loading , setLoading] = useState(false)
  let massiv = []
  const api_key = "a65b5937cb45a85fc91cb5e8065787f1"
  const images = "https://image.tmdb.org/t/p/w500"

   useEffect(() => {

   axios.get(`https://api.themoviedb.org/3/person/popular?api_key=${api_key}&language=en-US&page=1`)
  .then((response) => {
    setLoading(true)
    setPopular(response.data.results)
    // console.log(response.data.results);
    console.log(response.data.results);
      
  })
   }, []);



  return (
    <div className='backgrounds'>
    <Header />
    <div className='container'>
     
     <Row>
 
       <Col md={12}>
       <h3 style={{marginTop: '30px'}}  data-aos="fade-right"
        data-aos-duration="1500"
     data-aos-easing="ease-in-sine">Popular People</h3>
       <Row  data-aos="fade-up"
     data-aos-duration="3000">
        {
           (loading ) ?
             popular.map((item,index) => {
            return(
                <Col style={{borderRadius:"30px"}} className=' ' md={3}>
                <Link style={{textDecoration: 'none'}} to={`/movies/people/${item.id}`}>
                  <div  className='card my-5 shadow' key={index}>
                           <img src={images + item.profile_path } />
                 <h5 style={{}}>{item.title || item.name}</h5>
               <p>{item.known_for[0].release_date || item.first_air_date}</p>
                  </div>
                </Link>
                 
            
              </Col> 
             
            )
          })
          
          :
           <h1>Loading...</h1>
        }
        </Row>
       </Col>
     </Row>
    </div>
    
    
    </div>
  )
}