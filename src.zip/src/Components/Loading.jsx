import React from 'react'
import { useState, CSSProperties } from "react";
import GridLoader from "react-spinners/GridLoader";

export default function Loading() {
  let [loading, setLoading] = useState(true);
  let [color, setColor] = useState("midnightblue");
  return (
    <div className="sweet-loading Loading">
    <div>
      <GridLoader  color={color} loading={loading} size={50} />     
    </div>
      
    </div>
   
  )
}
