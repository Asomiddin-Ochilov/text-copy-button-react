import './App.css';
import React,{useState,useEffect,} from 'react'
import Header from './Components/Header';
import Main from './Components/Main';
import axios from 'axios';
import Loading from './Components/Loading'

function App() {
  const [loading,setLoading] = useState(true);
 
    setTimeout(() => {

      setLoading(false)

    }, 500);

    if (loading === false) {

      setTimeout(() => {
        setLoading(false)
      }, 1000);

    }

    
    
   
  return (
    <div className="App">
    {
      (loading)?
    <Loading />
      
      :
      <div>
     <Header />
     <Main />
      </div>
  
    }
  
    </div>
  );
}


export default App;
