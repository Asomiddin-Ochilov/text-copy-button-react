import {Accordion, Form} from 'react-bootstrap'
import React , {useState} from 'react'
import { useDispatch } from 'react-redux';
import { addgenres } from './Components/state';

export default function Accardion() {
let dispatch = useDispatch()
 function GetValue(val) {
    let massiv = []
    console.log(val.target.value);
    massiv.push(parseInt(val.target.value) )
    console.log(massiv);
    dispatch({type:"card/addgenres" , payload:parseInt(val.target.value)})
 }


  return (
    <div>
  <Accordion className='accardion' defaultActiveKey="1">
  <Accordion.Item eventKey="0">
    <Accordion.Header>Filters</Accordion.Header>
    <Accordion.Body>
    <Form onChange={(item) => GetValue(item)}>
  {['checkbox'].map((type) => (
    <div key={`inline-${type}`} className="mb-3">
     <h4>Genre</h4>
      <Form.Check
        inline
        label="Action"
        name="group1"
        type={type}
        value={28}
        id={`inline-${type}-1`}
      />
      <Form.Check
        inline
        label="Drama"
        name="group1"
        type={type}
        value={18}
        id={`inline-${type}-2`}
      />
        <Form.Check
        inline
        label="Family"
        name="group1"
        value={10751}
        type={type}
        id={`inline-${type}-2`}
      />
     <Form.Check
        inline
        label="Romance"
        name="group1"
        value={10749}
        type={type}
        id={`inline-${type}-2`}
      />
    <Form.Check
        inline
        label="Fantasy"
        name="group1"
        value={14}
        type={type}
        id={`inline-${type}-2`}
      />
       <Form.Check
        inline
        label="Horror"
        name="group1"
        value={27}
        type={type}
        id={`inline-${type}-2`}
      />
       <Form.Check
        inline
        label="Thriller"
        name="group1"
        value={53}
        type={type}
        id={`inline-${type}-2`}
      />
      <Form.Check
        inline
        label="Comedy"
        value={35}
        type={type}
        id={`inline-${type}-3`}
      />
    <Form.Check
        inline
        label="History"
        value={36}
        name="group1"
        type={type}
        id={`inline-${type}-2`}
      />
    </div>
  ))}
   <button className='btn btn-primary form-control' >Search</button>
</Form>
    </Accordion.Body>
  </Accordion.Item>
 
</Accordion>
    </div>
  )
}


